<!doctype html>
<head><title>welcome</title></head>

<body background="authimg.jpg" style="background-size:1270px;">
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #339EFF;
}

.topnav a {
  float: left;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color:#33E8FF;
  color: white;
}

.topnav a.active {
  background-color:;
  color: white;
}
</style>
</head>
<body>



<div style="padding-left:16px">
  
</div>

</body>
</html>

<div class="topnav">
  <a class="active" href="viewannounce.php">Announcements</a>
  <a href="displaycand.php">Candidates list</a>
  <a href="candidateapply.php">Apply for candidate</a>
    <a href="vote.php">Vote</a>
	<a href="profile.php">Profile</a>

  <a href="seeresults.php">Results</a>
  
  </div>

</body>
</html>