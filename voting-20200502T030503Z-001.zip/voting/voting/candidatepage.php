<!doctype html>
<head><title>welcome</title></head>

<body background="authimg.jpg" style="background-size:1270px;">
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #339EFF;
}

.topnav a {
  float: left;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color:#33E8FF;
  color: white;
}

.topnav a.active {
  background-color:;
  color: white;
}
</style>
</head>
<body>



<div style="padding-left:16px">
  
</div>

</body>
</html>

<div class="topnav">
  <a class="active" href="pub.php">Make Publications</a>
  <a class="active" href="adv.php">Provide Advertisements</a>
  <a href="displaypartyicon.php">Display Party Icon</a>
  </div>

</body>
</html>